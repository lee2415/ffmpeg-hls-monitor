#!/bin/bash
echo "Installing MultiView Monitor..."
sudo cp multiview-monitor /usr/local/bin/
sudo chmod +x /usr/local/bin/multiview-monitor
echo "Installation complete! Run: multiview-monitor --help"
